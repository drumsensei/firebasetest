
import pyrebase
import json

from .forms import UserRegisterForm

from django.contrib.messages.api import error
from  django.contrib import messages, auth

from django.shortcuts import render, redirect




firebaseConfig = {
    'apiKey': "AIzaSyBVyvXZcqZwQYe52eACfZ94jfVu8I5Qly4",
    'authDomain': "drumsense-cd382.firebaseapp.com",
    'projectId': "drumsense-cd382",
    'databaseURL':"https://drumsense-cd382-default-rtdb.firebaseio.com/",
    'storageBucket': "drumsense-cd382.appspot.com",
    'messagingSenderId': "409644584534",
    'appId': "1:409644584534:web:80df9faf1dcaa7ff95b5f7",
    'measurementId': "G-NYNS22RR4J"
}


firebase = pyrebase.initialize_app(firebaseConfig)

auth_user = firebase.auth()
db = firebase.database()
storage = firebase.storage()

# Create the firebase authentication logic for register, login, logout, resetPassword


def loginUser(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            user = auth_user.sign_in_with_email_and_password(username, password)
            session_id = user['idToken']
            request.session['uid'] = str(session_id)
            return render(request, 'drumsense/home.html', {"authenticated": True,})

        except:
           messages.warning(request,("Incorrect username or password"))
           return redirect('login')
 
    else:

        return render(request, 'userAuth/login.html')




def logoutUser(request):
    auth.logout(request)
    messages.success(request,("You have logged out"))
    return render(request, 'userAuth/logout.html', {})


def registerUser(request):

    email =''; password=''; password2 =''; project_name =''

    if request.method=='POST':
        form = UserRegisterForm(request.POST)
        project_name = request.POST.get('project_name')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        password2 = request.POST.get('password2')

        if password != password2:
            error_message = 'Password did not match'
            messages.warning(request,(error_message))
            return render(request, 'userAuth/registerUser.html', {'form': form})

        try:
            user = auth_user.create_user_with_email_and_password(email, password)
            session_id = user['idToken']
            db.child(user['localId']).child("projectName").set(project_name)                 
            db.child(user['localId']).child("Email").set(email)           
            # db.child(user['localId']).child("Password").set(password)            
            db.child(user['localId']).child("ID").set(user['localId'])
           
            if form.is_valid():
                messages.success(request, f"Your account has been created with email ID '{email}' ! You are now able to log in")
                # return redirect('login')
                return render(request, 'userAuth/login.html')

        except Exception as e:

            error_json = e.args[1]
            error = json.loads(error_json)['error']
            error_message = error['message']
            messages.warning(request,("Your account could not be created as " + error_message))
            return render(request, 'userAuth/registerUser.html', {'form': form})

    else:
        form = UserRegisterForm()
        return render(request, 'userAuth/registerUser.html', {'form': form})


def resetPassword(request):

    if request.method == 'POST':
        emailID = request.POST['userEmail']
        
        try:                      
            link = auth_user.send_password_reset_email(emailID)            
            messages.success(request,("Password reset instruction has been sent to your registered email"))
            return render(request, 'userAuth/password_reset_done.html', {})
        except Exception as e:

            error_json = e.args[1]
            error = json.loads(error_json)['error']
            error_message = error['message']
            messages.warning(request,("Could not reset your password (" + error_message + ")"))
            return redirect('login')

    else:

        return render(request,'userAuth/resetPassword.html', {})