from django.shortcuts import render

from .forms import UserRegisterForm

# Create your views here.

def index(request):
    return render(request, 'userAuth/index.html')




