from django.urls import path
from . import views, firebaseAuth

urlpatterns = [
    path('', views.index, name = 'index'),
    path('registerUser/', firebaseAuth.registerUser, name = 'registerUser'),
    path('login/', firebaseAuth.loginUser, name = 'login'),
    path('logout/', firebaseAuth.logoutUser, name = 'logout'),
    path('resetPassword/', firebaseAuth.resetPassword, name = 'resetPassword'),

]
