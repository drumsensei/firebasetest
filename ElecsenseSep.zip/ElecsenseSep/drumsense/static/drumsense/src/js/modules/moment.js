// Usage: https://momentjs.com/
import moment from "moment";

window.moment = moment;